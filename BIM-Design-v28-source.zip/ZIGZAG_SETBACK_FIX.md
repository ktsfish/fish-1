# Zigzag DXF setback correction

Existing project: `appgprj_6ac8472fc6608191be5324f3c978762e`.
Recovery point: saved version 27, source `9c320820eedce57f6b3af8e9197b49c1f883acb6`. Version 26 (`1317c73e4275540a5c30a8308744587483d172c7`) also remains recoverable. The latest source was reconciled before publishing; its additional zigzag and DXF integration regression tests are retained.

## Reported problem and cause

The supplied screenshot shows straight zigzag plot edges but circular cutouts in the setback/footprint geometry. The old Custom DXF envelope subtracted a full disk around every selected segment endpoint, including vertices next to edges with no setback. These disks created real erroneous area reductions, not merely a display issue.

## Implemented correction

- `dist/custom-dxf-geometry.js`: replace symmetric strips and endpoint disks with finite inward strips. Use the intersection of adjacent offset lines to close a concave corner. Convex corners use the overlap of their strips. Resolve all cuts in one polygon boolean operation to avoid accumulated near-coincident intersection errors. Retain every disconnected buildable component and report invalid geometry instead of inventing a replacement.
- `dist/custom-dxf.js`: update the calculation/report method note to describe the corrected construction.
- `tests/custom-dxf.test.cjs`, `tests/workspace.test.cjs`, and `tests/fixtures/*`: add the regression cases and independent reference geometries. Historic parity assertions explicitly exclude the two corrected files and geometry outputs whose old method was wrong; all other runtime assets remain checked byte-for-byte against version 27.

Original DXF coordinates, analytic area, units, arc lengths, and source bulges are unchanged. The existing arc sampling tolerance remains 1 mm. The manual calculation branch, v19 assets and lookup tables, floor counting formulas, 2D dimensions/sections, UI, 3D viewer and PDF renderer are unchanged. Corrected Custom envelope geometry flows through the existing footprint/GFA calculation into the plan, 3D floor records and report. Values may therefore change for DXF sites affected by the old error.

## Verification

`npm test`: **58 passed, 0 failed, 0 skipped**, plus the original geometry regression script. Syntax and whitespace checks passed. Full results: `qa/zigzag-test-results.txt`.

Coverage added for straight zigzag/reflex corners, an unchecked left setback, a short selected edge, unequal edge groups, reverse winding, CAD rotation, mm conversion, disconnected regions, complete envelope collapse, immutable original geometry, and the full DXF-to-GFA/3D/PDF integration path. Subsequent setback edits recalculate the same shared geometry and metrics.

The explicitly synthetic `zigzag-regression.dxf` has a 2,480 m² site and, with front/right/back setbacks of 6 m and left disabled, a 1,592 m² envelope. Its resulting edges remain straight and axis-aligned. It is not a reconstruction of the user's plot.

588 deterministic synthetic reference cases (seed 76026) were independently generated with Shapely 2.1.2 / GEOS 3.13.1 using inward miter buffering. The production JS output was compared with GEOS using full symmetric-difference area: 0 failures, maximum difference 2.198826477415904e-13 m². Reference miter limit 1e10 prevents reference beveling; no numeric miter cap or snapping was added to the production engine. Results: `qa/zigzag-oracle-results.json`. The committed JS regression compares area, component count, and bidirectional boundary distances with those same independent fixtures.

## Limits and project confirmation

- The user supplied a screenshot, not the original DXF. Exact reproduction and validation of that particular site's geometry remain unverified.
- The managed browser file chooser timed out, and preview subsequently reported stopped. Browser upload, visual rendering, WebGL interaction and PDF pagination were not verified in this correction. DOM integration tests did exercise file loading and dependent output updates. No alternative browser infrastructure was substituted.
- This is a geometric construction using the existing front/right/back/left edge assignments and unchanged setback inputs. It does not establish the legally approved building line. The user must confirm edge grouping and the approved setback/building-line interpretation against project documents. No legal reference was added or fabricated.
- Existing Custom DXF support limits (one selected closed boundary, no inferred holes or DWG assembly, session-only data) remain as documented in CUSTOM_DXF_CHANGELOG.md.

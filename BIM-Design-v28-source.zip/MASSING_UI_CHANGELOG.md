# 3D Massing and workspace UI — 2026-10-18

## Recovery point and scope
Existing project appgprj_6ac8472fc6608191be5324f3c978762e, public audience preserved. Saved version 24, source dbe3ecf83b7588448623766cb7854683f7c116d8, is the recoverable pre-change revision. The original v19 engine and the v24 DXF/2D additions remain unchanged. This change adds a read-only presentation layer, not a new calculation method.

## Implementation
- dist/massing-model.js: copies the current calculated footprints into floor records with original areas, floor counts, heights, elevations, GFA classifications and source notes. Geometry/result area discrepancies produce a 3D-only error, not a substituted value.
- dist/massing-viewer.mjs: local Three.js viewer with orbit, pan, zoom, six standard views, floor ray picking, layer visibility, X/Y/Z sections, reverse section direction and exploded floors. Polygon clipping creates closed section profiles, including concave outlines, holes and disconnected components. Display sections/explosion do not change original floor areas, elevations or totals.
- dist/workspace.js and dist/workspace.css: sidebar with the original input elements and event handlers; central viewer; bottom drawer for original results, exact calculation/formula output, interpolation, reference tables, legal-status content and complete original guide. All original 2D content is retained in Plan, Elevation, Road Section and All 2D views, including dimensions, descriptions, legends and setback controls.
- dist/index.html: adds only the new stylesheet and two additive scripts.
- dist/vendor/three.* and OrbitControls.mjs: self-hosted Three.js 0.180.0, MIT licence retained; no CDN or API is required by the deployed viewer.
- tests/workspace.test.cjs: calculation/2D/PDF compatibility, DOM integration, read-only model tests and real Three.js geometry/raycaster tests. package.json/lock add the pinned test dependency and new test command.

## Geometry and calculation preservation
Every pre-existing runtime asset except the index script/style includes is byte-identical to saved v24. This includes engine.js, data.js, geometry.js, massing.js, massing-drawing.js, custom-dxf-geometry.js, custom-dxf.js, export-pdf.js, illustration.js and their styles/assets. No regulatory table, validation rule, setback, GFA, FAR, tum or basement counting rule was changed.
3D podium and tower use exactly the polygons already shown/calculated by the app. DXF arcs use the existing polygon sampling tolerance; original analytic site area/dimensions stay in the existing engine/2D renderer. Floor GFA remains the engine's entire floor area when a display section removes part of the visible solid. FAR caps remain warnings, never replacement GFA.
Basement/tum plans have no designed source geometry in the current engine. They are explicitly labelled schematic: default basement follows the existing floor footprint; a separately entered basement area is fitted within the lot for display; the tum is fitted into the upper floor polygon to match the original tum area. These display-only positions do not update inputs or calculations.
The existing PDF remains a 2D calculation report. It does not receive a new 3D page or altered calculation content. The FAR-only lookup retains its existing behavior because it has no floor geometry/counts from which to construct a floor model.

## Verification
The unchanged original geometry regression script passes. 31 existing tests pass. 13 new tests pass, with zero failures/skips:
- Exact comparison against v24 across residential, mixed-use and individual housing, edits, roads/setbacks, basement/tum and FAR warnings.
- Curved/concave DXF and setback changes: identical results, trace, source tables, source 2D markup and generated PDF markup (only per-instance SVG IDs normalized).
- Floor source areas/elevations and summed above-ground/basement/FAR areas.
- X/Y/Z cuts, layers, explosion, floor selection and bottom-panel interactions do not mutate inputs or calculated results.
- Invalid inputs/imports clear the model; source reset/tab switching recover correctly.
- WebGL absence and 3D-only errors leave calculation, 2D and PDF operational.
- Actual Three.js mesh volumes and Raycaster hits, including DXF curves, closed X/Y/Z cuts, holes and disconnected regions.

## Verification limits and retained assumptions
The supported control-browser capability is unavailable in this environment. No browser preview, GPU/WebGL raster inspection, real pointer/touch browser QA, visual responsive review or PDF pagination check is claimed. CPU Three.js geometry, module import, ray picking and jsdom integration are tested. WebGL2 is required for the interactive renderer; an explicit message and the unchanged 2D/PDF workflow remain available without it.
The current legal references, applicability notes, counting assumptions, basement maximum and session-only data behavior are preserved verbatim; this UI change does not approve them for an individual project. The 3D mass is a conceptual calculation model, not a designed structural/architectural model.

## FAR tab UI alignment — 2026-10-22
The Hệ số sử dụng đất tab now uses the same workspace shell as the building tabs: the original area/height inputs in the sidebar, unchanged height illustration in the central view, mirrored result metrics across the top, and result/interpolation/formula/reference/guide panels in the bottom drawer. It keeps its height-only behavior and does not invent floor records or a building footprint.
Only dist/workspace.js and dist/workspace.css changed at runtime. Every other v25 runtime file, including index, engine, data, calculation, 2D drawings and PDF code, remains byte-identical. Top GFA/FAR metrics copy the original formatted output, retaining precision. The original PDF content and validation/reset behavior are preserved. The legacy FAR test now compares original content panels instead of the intentionally changed outer layout.
48/48 tests pass, no failures/skips, plus the original geometry regression script. Four additional tests verify shared FAR layout, numerical/table-boundary/PDF parity, invalid-input recovery/reset/tab switching, and unchanged non-UI runtime assets. Desktop browser QA verified input edits, synchronized metrics/height illustration, and opening/closing the formula drawer. Browser sample: 7,200 m², 31 m → FAR 6.38, ceiling GFA 45,936 m². Evidence and full test output are in qa/far-workspace.jpg and qa/far-test-results.txt. No mobile visual or PDF pagination verification is claimed.
Recovery point: saved version 25, source dccf5dde490b2bb53768beeb100ce3b3c4a14795.

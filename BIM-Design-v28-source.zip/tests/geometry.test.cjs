const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const dist=path.join(__dirname,'../dist');
const context=vm.createContext({render(){},calculate(){},f:v=>String(v),structuredClone});
for(const name of ['data.js','engine.js','geometry.js'])vm.runInContext(fs.readFileSync(path.join(dist,name),'utf8'),context,{filename:name});
const massing=fs.readFileSync(path.join(dist,'massing.js'),'utf8');
vm.runInContext(massing.slice(0,massing.indexOf('function setbackReference')),context);
const run=code=>vm.runInContext(code,context);
const close=(a,b)=>assert(Math.abs(a-b)<=1e-7*Math.max(1,Math.abs(b)),`${a} != ${b}`);

// Four 6 m edge strips overlap at corners. A naive band subtraction returns 0;
// the actual surviving rectangle has area 8 * 18 = 144 m².
close(run('insetRegion(rectangleRegion(0,0,20,30).polygon,[6,6,6,6]).area'),144);
close(run('insetRegion(rectangleRegion(0,0,20,30).polygon,[0,0,0,0]).area'),600);
assert.equal(run('insetRegion(rectangleRegion(0,0,20,30).polygon,[15,0,15,0]).area'),0);
close(run('intersectRegions(rectangleRegion(0,0,20,20).polygon,rectangleRegion(10,10,20,20).polygon).area'),100);

// Oblique-edge fixture: an independent integral of trapezoid width between
// y=2 and y=27, after 1 m and 4 m normal offsets of the oblique side lines.
const trapezoidOracle=(20-5*Math.sqrt(916)/30)*25-(4/30)*(27*27-2*2);
close(run('insetRegion([{x:0,y:0},{x:20,y:0},{x:16,y:30},{x:4,y:30}],[2,4,3,1]).area'),trapezoidOracle);

run("var sample=[600,3,4,10,3,3,0,.6],fixture=makeExtra('res');fixture.length=30;fixture.roads.forEach(r=>{r.on=true;r.width=16});var base=constrained('res',sample,fixture)");
close(run('base.P'),450);close(run('base.T'),144);close(run('base.gfa'),2790);
assert(run('base.gfa<base.cap'));close(run('base.lossBySetback'),run('base.beforeSetback-base.raw'));
for(const block of ['p','t'])for(let face=0;face<4;face++){
  run(`var changedExtra=structuredClone(fixture);changedExtra.roads[${face}].${block}=${block==='p'?10:7};var changed=constrained('res',sample,changedExtra)`);
  assert(run('changed.gfa<base.gfa'),`Increasing ${block} setback on face ${face} must reduce geometry-bound GFA`);
  close(run('changed.cap'),run('base.cap'));
  close(run('polygonArea(changed.footprints.podium.polygon)'),run('changed.P'));
  close(run('polygonArea(changed.footprints.tower.polygon)'),run('changed.T'));
  close(run('intersectRegions(changed.footprints.podium.polygon,changed.ep.polygon).area'),run('changed.P'));
  close(run('intersectRegions(changed.footprints.tower.polygon,changed.shared.polygon).area'),run('changed.T'));
  close(run('intersectRegions(changed.footprints.tower.polygon,changed.footprints.podium.polygon).area'),run('changed.T'));
}
assert.throws(()=>run("constrained('res',sample,{...fixture,roads:fixture.roads.map((r,i)=>({...r,t:i===0?5:''}))})"),/phải ≥ 6/);
assert.throws(()=>run("constrained('res',sample,{...fixture,roads:fixture.roads.map((r,i)=>({...r,p:i===0?30:''}))})"),/vùng xây dựng hợp lệ/);

// FAR is a reference ceiling: keep the geometry/coverage floor areas, then
// warn when the GFA from the entered storeys exceeds it. No automatic scaling.
run("var large=[19531.6376,5,4.5,17,3,0,0,0],largeExtra=makeExtra('res');largeExtra.roads.forEach(r=>{r.on=true;r.width=16});var capped=constrained('res',large,largeExtra)");
assert(run('capped.raw>capped.cap'));close(run('capped.gfa'),run('capped.raw'));assert(run('capped.exceedsCap'));close(run('capped.overCap'),run('capped.raw-capped.cap'));
run("var mild=structuredClone(largeExtra);mild.roads[0].t=80;var mildResult=constrained('res',large,mild)");
assert(run('mildResult.raw<capped.raw'));assert(run('mildResult.gfa<capped.gfa'));assert(run('mildResult.exceedsCap'));close(run('mildResult.gfa'),run('mildResult.raw'));
for(let face=0;face<4;face++){
  run(`var severe=structuredClone(largeExtra);severe.roads[${face}].t=120;var reduced=constrained('res',large,severe)`);
  assert(run('reduced.raw<reduced.cap'));close(run('reduced.gfa'),run('reduced.raw'));assert(run('reduced.gfa<capped.gfa'));assert.equal(run('reduced.exceedsCap'),false);assert.equal(run('reduced.overCap'),0);
}
for(const result of ['base','changed','capped','mildResult','reduced']){
  close(run(`polygonArea(${result}.footprints.podium.polygon)`),run(`${result}.P`));
  close(run(`polygonArea(${result}.footprints.tower.polygon)`),run(`${result}.T`));
  close(run(`intersectRegions(${result}.footprints.tower.polygon,${result}.footprints.podium.polygon).area`),run(`${result}.T`));
  close(run(`${result}.P`),run(`${result}.Pmax`));close(run(`${result}.T`),run(`${result}.Tmax`));
  close(run(`${result}.gfaP+${result}.gfaT`),run(`${result}.gfa`));
}

// Exact workflow-image case: podium/tower regions 2142/1921 m² but coverage
// caps both floors at 1875 m². Storey counts produce 41250, not the FAR cap 32000.
run("var diagramExtra=makeExtra('res');diagramExtra.length=40;var diagram=constrained('res',[2500,5,4.5,17,3,3,0,0],diagramExtra)");
for(const [key,value] of Object.entries({ep:2142,shared:1921}))close(run(`diagram.${key}.area`),value);
for(const [key,value] of Object.entries({P:1875,T:1875,gfaP:9375,gfaT:31875,gfa:41250,cap:32000,overCap:9250,proposal:562.5}))close(run(`diagram.${key}`),value);
assert(run('diagram.exceedsCap'));
run("var coverageOnly=structuredClone(diagramExtra);coverageOnly.roads[0].p=5;var plateau=constrained('res',[2500,5,4.5,17,3,3,0,0],coverageOnly)");
assert(run('plateau.ep.area<diagram.ep.area'));close(run('plateau.P'),run('diagram.P'));close(run('plateau.gfa'),run('diagram.gfa'));
run("var geometryBound=structuredClone(diagramExtra);geometryBound.roads[0].p=10;var shrinking=constrained('res',[2500,5,4.5,17,3,3,0,0],geometryBound)");
assert(run('shrinking.P<diagram.P && shrinking.T<diagram.T && shrinking.gfa<diagram.gfa && shrinking.exceedsCap'));
run("geometryBound.roads[0].p=20;var below=constrained('res',[2500,5,4.5,17,3,3,0,0],geometryBound)");
assert(run('below.gfa<below.cap && !below.exceedsCap'));
run("var atCapExtra=makeExtra('res');atCapExtra.length=50;atCapExtra.roads.forEach((r,i)=>{r.on=i===0;r.t=18});var atCap=constrained('res',[2500,0,4,20,3,0,0,0],atCapExtra)");
close(run('atCap.gfa'),32000);close(run('atCap.gfa'),run('atCap.cap'));assert.equal(run('atCap.exceedsCap'),false);assert.equal(run('atCap.overCap'),0);
run("var onlyTower=constrained('res',[600,0,4,10,3,0,0,.6],fixture),onlyPodium=constrained('res',[600,3,4,0,3,0,0,.6],fixture),house=constrained('home',[150,3,3.6,0,3,0,0,0],makeExtra('home'))");
assert.equal(run('onlyTower.P'),0);assert.equal(run('onlyPodium.T'),0);close(run('house.gfa'),360);
console.log('PASS: polygon clipping, corner overlap, oblique boundaries, all four applied setbacks, below-minimum rejection, empty regions, nested area-exact footprints, no FAR scaling, exact workflow case, coverage plateau, GFA reduction while above cap, warning clearance below/at cap, separate blocks and home.');

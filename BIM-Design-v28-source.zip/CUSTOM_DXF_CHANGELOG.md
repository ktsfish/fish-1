# Custom DXF input — additive extension of version 19

Project: appgprj_6ac8472fc6608191be5324f3c978762e.
Baseline: version 19 / source 655f3d5c8c59c29d5de1aa6aeec8444035e62c08.

## Scope and preservation
All runtime JS, CSS, datasets, images and geometry regression tests existing in version 19 remain byte-identical. index.html only adds stylesheet/script references. Version 20/21 experimental foundation components are not loaded or used. A regression test reads the actual v19 Git objects and compares every original asset byte-for-byte.

The manual branch delegates directly to the preserved v19 calculations, drawings and report functions. Tests compare output metrics, HTML results, trace tables and printed-report markup against a separately loaded original v19 app, including its floor counts, tum, basement and FAR/reference/guide tabs.

## User workflow
Within Thông số công trình: Nhập tay (default) or Custom · ranh thực tế DXF.
Custom disables only the hand-entered site area and optional length inputs, retains their values, and exposes one DXF upload with default metre units. After a valid boundary is loaded, source area and dimensional geometry feed all existing density/FAR/height/GFA/basement/tum calculations. Selecting manual restores the old inputs. Custom without valid geometry clears results and disables PDF; it never silently uses stale manual area.

Straight and bulged closed LWPOLYLINE/POLYLINE boundaries are supported. Exact original vertices, bulges and DXF source text remain in memory. Area includes exact circular-segment contributions; arc length uses radius × swept angle. Display orientation is derived independently and aligns the longest straight edge horizontally (longest chord if all edges are arcs). Source CAD coordinates are never changed. Per-edge default face groups can be overridden, and the front/back orientation can be flipped.

Dimensions of every original CAD edge/arc, site area and horizontal/vertical extents are integrated into the plan. Irregular-site area is never replaced by width × length. Other v19 inputs remain editable. The original regulatory tables and counting assumptions are retained without new legal assertions.

Custom uses actual polygon operations for separate podium/tower envelopes and their intersection. Applied setbacks come from the unchanged v19 road/height table logic and the face assigned to each source edge. The original extension used round endpoint clearances; this was corrected after version 26 to inward edge offsets and miter intersections at concave corners, without artificial circular cuts in straight zigzag boundaries. Confirm the geometric interpretation against approved building lines. Arc sampling has <=0.001 m chord error. Source site area/perimeter remain exact analytic values. Footprints are conceptual maximum-area diagrams, as in v19, not designed floor layouts. Their displayed/calculated areas come from the same clipped geometry. FAR remains a warning ceiling, not a substituted GFA value. See ZIGZAG_SETBACK_FIX.md for the correction and its verification.

The Custom road section intersects the actual footprint polygons along a normal through the selected CAD edge; multiple edges in a face can be selected separately. An arc uses the local sampled tangent near its midpoint. Non-intersecting floors are reported as such, not drawn from a bounding rectangle. PDF has matching Custom geometry formulas/dimensions while the manual PDF stays byte-for-byte equivalent in tests.

## Files added
- dist/custom-dxf-geometry.js: CAD geometry, exact arc metrics, orientation, validation, clipping and section intersections.
- dist/custom-dxf.js: optional source selector, source adapter, dimensions, Custom drawings and PDF hooks.
- dist/custom-dxf.css: local styles.
- dist/vendor/*: polygon-clipping 0.15.7 and dxf-parser 1.1.2, both with MIT licence files.
- tests/custom-dxf.test.cjs and tests/custom-ui.test.cjs; package.json/lockfile and .gitignore for test tooling.

## Verification
npm test: 27/27 new tests passed, zero failures/skips. Original geometry regression script also passed. Syntax and git whitespace checks passed.
Coverage: exact rectangular/concave geometry, arcs and negative bulges, units/default m, self intersections/open boundaries, disconnected buildable regions, per-face setbacks, nested footprint area/containment, arbitrary CAD rotation/translation, real section intersections, manual mode parity against v19, authoritative DXF inputs, locking/restoration, existing downstream controls, PDF, multiple-boundary selection, invalid-file clearing, house/tower-only cases and async file uploads across tabs.
DOM integration uses jsdom with ResizeObserver stubbed. The supported control-browser capability was unavailable, so there is no claim of visual browser QA, file-dialog testing or visually verified PDF pagination/responsive layout. No alternative browser or preview server was used.

## Boundaries of support
- DWG must be saved/exported as DXF ASCII. Unjoined LINE/ARC entities and INSERT/BLOCK boundaries are not assembled; use closed polyline/PEDIT JOIN. Splines, curve-fit polylines, meshes and non-XY WCS geometry are rejected explicitly.
- One selected closed boundary is supported in this scope; a drawing with multiple boundaries requires explicit selection. Nested plot holes are not inferred from other polylines.
- Default reading unit is m even when $INSUNITS differs. A visible mismatch note is shown; the user can select mm/cm explicitly. No silent scale conversion is applied.
- Existing v19 treatment of technical roof/basement area, FAR table applicability and other regulatory assumptions are unchanged and still require the user's project/legal review.
- Records and source CAD are held in the browser session, matching v19's in-memory workflow. No new persistence or cloud CAD storage is claimed.
- Saved version 19 remains available for native rollback.

## Dimension layout correction
The DXF plan has a separate area heading and orientation strip. Overall dimensions occupy outer rails; long-edge and arc labels are only placed when their estimated rotated text boxes fit without collisions. Short/dense edges are keyed by edge ID with length and assigned face in a responsive grid immediately below the drawing. All edge dimensions remain represented exactly once. No multi-leader fan extends to the distant lower-right corner. The same renderer is used in the source preview, integrated illustration and Custom PDF.
Only custom-dxf.js rendering, custom-dxf.css and layout tests changed; geometry/calculation modules were not changed. 28/28 new tests passed plus the unchanged original geometry regression script. The added 10-edge fixture checks 280/320/480/650/850 px widths for text-box separation, boundary fit, and complete edge references. These are computed layout checks; browser font rendering/responsive PDF pagination are not visually verified. A separate static SVG raster check was unavailable because the system SVG conversion delegate was missing.

## Legend and curved dimensions
Added a shared four-key plan legend in manual/Custom views and PDF: red road boundary, purple dashed setback boundary, existing green podium and warm gold tower. Custom boundary overlays match the keys. Arc dimensions use SVG textPath on parallel offset curves, with local endpoint ticks, readable tangent direction and collision/containment checks. Curves never enter the short straight-edge key. Extra annotation space is reserved for dense plots; an explicit expand-view message is used if no safe placement is found. Original CAD geometry and calculation code are unchanged.
31/31 tests passed, zero failures/skips, plus the original geometry regression checks. New coverage checks legend/color mappings, curved paths across widths 280–850 px, and manual GFA parity. Existing v19 assets remain byte-identical; manual PDF comparison excludes only the new legend wrapper. Browser font rendering and PDF pagination remain unverified because the supported browser capability is unavailable.
